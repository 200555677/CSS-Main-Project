const swiper = new Swiper(".banner-swiper", {
  effect: "slide",
  speed: 1000,
  loop: true,
  autoplay: {
    delay: 3000,
  },
});
